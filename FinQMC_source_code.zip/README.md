This repository is the implementation of my academic paper.

You may need to put this dictionary in site-packages to test its functions.